//import _ from 'lodash';

//it('Should be a sum greater than 7', () => {
//    expect(_.add(3, 5)).toBeGreaterThan(7);
//});
